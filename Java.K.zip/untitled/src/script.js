// Project Data (You can add as many as you like)

const projects = [

  { title: "Personal Website", description: "My first website using HTML, CSS, and JavaScript." },

  { title: "Calculator App", description: "A simple calculator made with JavaScript." },

  { title: "Portfolio", description: "This very portfolio you are looking at!" }

];

// Load projects dynamically

const projectList = document.getElementById("projectList");

projects.forEach(project => {

  const card = document.createElement("div");

  card.classList.add("project-card");

  card.innerHTML = `<h3>${project.title}</h3><p>${project.description}</p>`;

  projectList.appendChild(card);

});

// Theme Toggle

const themeToggle = document.getElementById("themeToggle");

themeToggle.addEventListener("click", () => {

  document.body.classList.toggle("dark-theme");

});